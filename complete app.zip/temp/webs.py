import asyncio
import logging
from datetime import datetime
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from ta.trend import SMAIndicator
from SmartApi.smartWebSocketV2 import SmartWebSocketV2
import pyotp
from websocket import WebSocketApp




# Initialize FastAPI app
app = FastAPI()

# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Set up logging
logging.basicConfig(
    filename="activity.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logging.info("Application started.")

# Replace with your actual credentials
API_KEY = 'mrGAmTyy'
CLIENT_CODE = 'DIHV1008'
PASSWORD = '1982'
TOTP_TOKEN = '43X7CRFHVDVEGZX56PZVN4NE2I'

# Initialize SmartConnect and generate session
from SmartApi import SmartConnect

smart_api = SmartConnect(api_key=API_KEY)
totp = pyotp.TOTP(TOTP_TOKEN).now()

try:
    session_data = smart_api.generateSession(CLIENT_CODE, PASSWORD, totp)
    if session_data['status']:
        logging.info("Login successful.")
        auth_token = session_data['data']['jwtToken']
        refresh_token = session_data['data']['refreshToken']
        feed_token = smart_api.getfeedToken()  # Required for WebSocket connection
    else:
        logging.error(f"Login failed: {session_data['message']}")
except Exception as e:
    logging.error(f"Error during login: {e}")

# Initialize WebSocket client
ws_client = SmartWebSocketV2(auth_token, API_KEY, CLIENT_CODE, feed_token)

SYMBOL_LIST = [
    "IDEA", "POLYCAB", "DABUR", "INDHOTEL", "PAGEIND", "CUMMINSIND", "INDIGO",
    "GLENMARK", "NAUKRI", "TORNTPHARM", "SRF"
]

# Token map and signal storage
token_df = pd.DataFrame()
signals = {}
live_data = pd.DataFrame(columns=['symbol', 'timestamp', 'open', 'high', 'low', 'close', 'volume'])

# Fetch token map
def fetch_token_map():
    url = 'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json'
    try:
        response = requests.get(url)
        if response.status_code == 200:
            token_df = pd.DataFrame(response.json())
            token_df['expiry'] = token_df['expiry'].str.strip()
            token_df = token_df.astype({'strike': float})
            logging.info("Token map fetched successfully.")
            return token_df
        else:
            logging.error("Failed to fetch token map.")
            return pd.DataFrame()
    except Exception as e:
        logging.error(f"Error fetching token map: {e}")
        return pd.DataFrame()

token_df = fetch_token_map()

# Helper to get token info
def get_token_info(symbol, exch_seg='NSE'):
    df = token_df
    eq_df = df[(df['exch_seg'] == exch_seg) & (df['symbol'].str.contains('EQ'))]
    return eq_df[eq_df['name'] == symbol]

# WebSocket message handler
def on_message(ws, message):
    global live_data, signals
    try:
        data = pd.DataFrame([message['d']], columns=['symbol', 'timestamp', 'open', 'high', 'low', 'close', 'volume'])
        data['timestamp'] = pd.to_datetime(data['timestamp'], unit='s')
        live_data = pd.concat([live_data, data]).groupby('symbol').tail(1)  # Keep the latest data for each symbol

        # Calculate indicators and generate signals
        for symbol in SYMBOL_LIST:
            symbol_data = live_data[live_data['symbol'] == symbol]
            if len(symbol_data) >= 200:  # Ensure sufficient data for SMA calculation
                df = symbol_data.copy()
                df['SMA_20'] = SMAIndicator(close=df['close'], window=20).sma_indicator()
                df['SMA_200'] = SMAIndicator(close=df['close'], window=200).sma_indicator()

                # Generate signal
                latest_close = df['close'].iloc[-1]
                sma_20 = df['SMA_20'].iloc[-1]
                sma_200 = df['SMA_200'].iloc[-1]

                if sma_20 > sma_200 and latest_close > sma_20:
                    signals[symbol] = {"signal": "BUY", "price": latest_close}
                    logging.info(f"Symbol: {symbol} | Signal: BUY | Price: {latest_close}")
                elif sma_20 < sma_200 and latest_close < sma_20:
                    signals[symbol] = {"signal": "SELL", "price": latest_close}
                    logging.info(f"Symbol: {symbol} | Signal: SELL | Price: {latest_close}")
    except Exception as e:
        logging.error(f"Error in message handler: {e}")

# WebSocket error handler
def on_error(ws, error):
    logging.error(f"WebSocket error: {error}")

# WebSocket close handler
def on_close(ws):
    logging.info("WebSocket connection closed.")

# WebSocket open handler
def on_open(ws):
    logging.info("WebSocket connection established.")
    # Subscribe to live data for all symbols
    for symbol in SYMBOL_LIST:
        token_info = get_token_info(symbol).iloc[0]
        token = token_info['token']
        ws.subscribe([{
            "token": token,
            "exchangeType": 1,  # NSE
            "symbol": symbol
        }])

# Start WebSocket client
ws_client.on_open = on_open
ws_client.on_message = on_message
ws_client.on_error = on_error
ws_client.on_close = on_close

async def start_websocket():
    logging.info("Starting WebSocket client.")
    ws_client.connect()

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(start_websocket())

@app.get("/signals")
async def get_filtered_signals():
    logging.info("Fetching latest signals.")
    return signals if signals else {"message": "No signals generated for the monitored stocks"}
