from smartapi import SmartConnect
import pandas as pd
from datetime import datetime, timedelta
import credentials
import requests
import numpy as np
from time import time, sleep
#from talib.abstract import *
import threading
import warnings
warnings.filterwarnings('ignore')
from ta.trend import IchimokuIndicator
from ta.trend import CCIIndicator
from ta.momentum import StochasticOscillator
from ta.momentum import RSIIndicator
from ta.trend import SMAIndicator
from ta.volatility import BollingerBands
from sklearn.preprocessing import MinMaxScaler




SYMBOL_LIST = ["IDEA",
"POLYCAB",
"DABUR",
"INDHOTEL",
"LUPIN",
"NATIONALUM"]

TRADED_SYMBOL = []
timeFrame = 60 + 5 #5 sec coz dealy repsone of historical API

rsiPeriod = 11
bandLength = 31
lengthrsipl = 1
lengthtradesl = 9

def place_order(token,symbol,qty,buy_sell,ordertype,price,variety= 'NORMAL',exch_seg='NSE',triggerprice=0):
    try:
        orderparams = {
            "variety": variety,
            "tradingsymbol": symbol,
            "symboltoken": token,
            "transactiontype": buy_sell,
            "exchange": exch_seg,
            "ordertype": ordertype,
            "producttype": "INTRADAY",
            "duration": "DAY",
            "price": price,
            "squareoff": "0",
            "stoploss": "0",
            "quantity": qty,
            "triggerprice":triggerprice
            }
        orderId=credentials.SMART_API_OBJ.placeOrder(orderparams)
        print("The order id is: {}".format(orderId))
    except Exception as e:
        print("Order placement failed: {}".format(e.message))

def intializeSymbolTokenMap():
    url = 'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json'
    d = requests.get(url).json()
    global token_df
    token_df = pd.DataFrame.from_dict(d)
    token_df['expiry'] = pd.to_datetime(token_df['expiry'])
    token_df = token_df.astype({'strike': float})
    credentials.TOKEN_MAP = token_df

def getTokenInfo (symbol, exch_seg ='NSE',instrumenttype='',strike_price = '',pe_ce = ''):
    df = credentials.TOKEN_MAP
    strike_price = strike_price*100
    if exch_seg == 'NSE':
        eq_df = df[(df['exch_seg'] == 'NSE') & (df['symbol'].str.contains('EQ')) ]
        return eq_df[eq_df['name'] == symbol]
    elif exch_seg == 'NFO' and ((instrumenttype == 'FUTSTK') or (instrumenttype == 'FUTIDX')):
        return df[(df['exch_seg'] == 'NFO') & (df['instrumenttype'] == instrumenttype) & (df['name'] == symbol)].sort_values(by=['expiry'])
    elif exch_seg == 'NFO' and (instrumenttype == 'OPTSTK' or instrumenttype == 'OPTIDX'):
        return df[(df['exch_seg'] == 'NFO') & (df['instrumenttype'] == instrumenttype) & (df['name'] == symbol) & (df['strike'] == strike_price) & (df['symbol'].str.endswith(pe_ce))].sort_values(by=['expiry'])


def calculate_inidcator(res_json):
    columns = ['timestamp','O','H','L','C','V']
    df = pd.DataFrame(res_json['data'], columns=columns)
    indicator_ichi = IchimokuIndicator(low = df["L"],high = df["H"],window1 = 9,window2 = 26,window3 = 52,visual = False,fillna = True)
    df["base_line"] = indicator_ichi.ichimoku_base_line()
    df["conversion_line"] = indicator_ichi.ichimoku_conversion_line()
    df["leading_span_a"] = indicator_ichi.ichimoku_a()
    df["leading_span_b"] = indicator_ichi.ichimoku_b()
    rsi = RSIIndicator(close = df['C'], window = rsiPeriod )
    df['RSI'] = rsi.rsi()
    sma = SMAIndicator(close = df['RSI'], window = bandLength )
    df['SMA'] = sma.sma_indicator() 
    bb = BollingerBands(close = df['RSI'], window = bandLength, window_dev  = 1.6185, fillna = False)
    df['up'] = bb.bollinger_hband()
    df['dn'] = bb.bollinger_lband()
    df['mid'] = bb.bollinger_mavg()
    fastsma = SMAIndicator(close = df['RSI'], window = lengthrsipl )
    df['FAST_SMA'] = fastsma.sma_indicator() 
    slowsma = SMAIndicator(close = df['RSI'], window = lengthtradesl )
    df['SLOW_SMA'] = slowsma.sma_indicator() 
    #print("--- Indicator Values Calculated")
    #print(df.tail(2))
    #print("----------------------------------------------------------------------------------")
    return df


def getHistoricalAPI(token,interval= 'ONE_HOUR'):
    sleep(2)
    to_date= datetime.now()
    from_date = to_date - timedelta(days=15)
    from_date_format = from_date.strftime("%Y-%m-%d %H:%M")
    to_date_format = to_date.strftime("%Y-%m-%d %H:%M")
    try:
        historicParam={
        "exchange": "NSE",
        "symboltoken": token,
        "interval": interval,
        "fromdate": from_date_format, 
        "todate": to_date_format
        }
        candel_json  = credentials.SMART_API_OBJ.getCandleData(historicParam)
        return calculate_inidcator(candel_json)
    except Exception as e:
        print("Historic Api failed: {}".format(e.message))

def checkSingnal():

    start = time()
    global TRADED_SYMBOL
    
    for symbol in SYMBOL_LIST :
        
        if symbol not in TRADED_SYMBOL:
            tokenInfo = getTokenInfo(symbol).iloc[0]
            token = tokenInfo['token']
            symbol = tokenInfo['symbol']
            print(symbol, token)
            candel_df = getHistoricalAPI(token)
            if candel_df is not None :
                latest_candel = candel_df.iloc[-1]
                previous_candel = candel_df.iloc[-2]
                if ((previous_candel['SLOW_SMA'] >= previous_candel['FAST_SMA']  )and (latest_candel['FAST_SMA'] > latest_candel['SLOW_SMA'] )and (previous_candel['mid'] >= 50)):
                    if ((latest_candel['FAST_SMA'] > latest_candel['mid'] )and (latest_candel['SLOW_SMA'] > latest_candel['mid'] )):
                        print("----------------BUY  SIGNAL GENERATED FOR------- ",{symbol})
                       
                        TRADED_SYMBOL.append(symbol)

                if ((previous_candel['SLOW_SMA'] <= previous_candel['FAST_SMA']  )and (latest_candel['FAST_SMA'] < latest_candel['SLOW_SMA'] )and (previous_candel['mid'] <= 50)):
                    if ((latest_candel['FAST_SMA'] < latest_candel['mid'] )and (latest_candel['SLOW_SMA'] < latest_candel['mid'] )):
                        print("-----------------SELL  SIGNAL GENERATED FOR------ ",{symbol})
                     
                        TRADED_SYMBOL.append(symbol)


    interval = timeFrame - (time()-start)   
    print(interval)
    threading.Timer(interval, checkSingnal).start()



if __name__ == '__main__':
    intializeSymbolTokenMap()
    obj=SmartConnect(api_key=credentials.API_KEY)
    data = obj.generateSession(credentials.USER_NAME,credentials.PWD)
    credentials.SMART_API_OBJ = obj
   
    interval = timeFrame - datetime.now().second
    print(f"Code run after {interval} sec")
    sleep(interval)
    checkSingnal()

   
