#replace  username,pwd, api_key  with yours
USER_NAME = 'DIHV1008'
PWD = 'kavya@2010'
API_KEY = 'HhYlEiDd'

#Dont change  below varibale 
FEED_TOKEN = None
TOKEN_MAP = None
SMART_API_OBJ = None



