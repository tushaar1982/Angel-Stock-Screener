from SmartApi import *
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from datetime import datetime, timedelta
import pyotp
import requests
from ta.trend import SMAIndicator
from ta.momentum import RSIIndicator
from ta.volatility import BollingerBands
from logzero import logger

# Initialize FastAPI app
app = FastAPI()



# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Replace with your actual credentials
API_KEY = 'mrGAmTyy'
CLIENT_CODE = 'DIHV1008'
PASSWORD = '1982'
TOTP_TOKEN = '43X7CRFHVDVEGZX56PZVN4NE2I'

# Initialize SmartConnect
smart_api = SmartConnect(api_key=API_KEY)

# Generate TOTP
totp = pyotp.TOTP(TOTP_TOKEN).now()

# Create a session
try:
    session_data = smart_api.generateSession(CLIENT_CODE, PASSWORD, totp)
    if not session_data['status']:
        logger.error(f"Login failed: {session_data['message']}")
    else:
        logger.info("Login successful")
        auth_token = session_data['data']['jwtToken']
        refresh_token = session_data['data']['refreshToken']
except Exception as e:
    logger.error(f"Error during login: {e}")

# Fetch token map
def fetch_token_map():
    url = 'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json'
    response = requests.get(url)
    if response.status_code == 200:
        token_df = pd.DataFrame(response.json())
        token_df['expiry'] = token_df['expiry'].str.strip()
        token_df = token_df.astype({'strike': float})
        return token_df
    else:
        logger.error("Failed to fetch token map")
        return pd.DataFrame()

token_df = fetch_token_map()

# List of symbols to monitor
SYMBOL_LIST = ["IDEA", "POLYCAB", "DABUR", "INDHOTEL", "LUPIN", "NATIONALUM"]

def get_token_info(symbol, exch_seg='NSE'):
    df = token_df
    eq_df = df[(df['exch_seg'] == exch_seg) & (df['symbol'].str.contains('EQ'))]
    return eq_df[eq_df['name'] == symbol]

def get_historical_data(symbol_token, interval='ONE_HOUR', days=15):
    to_date = datetime.now()
    from_date = to_date - timedelta(days=days)
    params = {
        "exchange": "NSE",
        "symboltoken": symbol_token,
        "interval": interval,
        "fromdate": from_date.strftime("%Y-%m-%d %H:%M"),
        "todate": to_date.strftime("%Y-%m-%d %H:%M")
    }
    try:
        historical_data = smart_api.getCandleData(params)
        if historical_data['status']:
            return historical_data['data']
        else:
            logger.error(f"Failed to fetch historical data: {historical_data['message']}")
    except Exception as e:
        logger.error(f"Error fetching historical data: {e}")
    return None

def calculate_indicators(candle_data):
    df = pd.DataFrame(candle_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df.set_index('timestamp', inplace=True)

    # Calculate RSI
    rsi_period = 11
    df['RSI'] = RSIIndicator(close=df['close'], window=rsi_period).rsi()

    # Calculate SMA
    sma_period = 31
    df['SMA'] = SMAIndicator(close=df['RSI'], window=sma_period).sma_indicator()

    # Calculate Bollinger Bands
    bb_period = 31
    bb_dev = 1.6185
    bb = BollingerBands(close=df['RSI'], window=bb_period, window_dev=bb_dev)
    df['BB_upper'] = bb.bollinger_hband()
    df['BB_lower'] = bb.bollinger_lband()
    df['BB_middle'] = bb.bollinger_mavg()

    # Fast and Slow SMA
    fast_sma_period = 1
    slow_sma_period = 9
    df['FAST_SMA'] = SMAIndicator(close=df['RSI'], window=fast_sma_period).sma_indicator()
    df['SLOW_SMA'] = SMAIndicator(close=df['RSI'], window=slow_sma_period).sma_indicator()

    return df

def generate_signal(df):
    latest = df.iloc[-1]
    previous = df.iloc[-2]

    # Buy Signal
    if (
        (previous['SLOW_SMA'] >= previous['FAST_SMA'])
    ):
        return 'BUY'

    # Sell Signal
    if (
        (previous['SLOW_SMA'] <= previous['FAST_SMA']) and
        (latest['FAST_SMA'] < latest['SLOW_SMA']) and
        (previous['BB_middle'] <= 50) and
        (latest['FAST_SMA'] < latest['BB_middle']) and
        (latest['SLOW_SMA'] < latest['BB_middle'])
    ):
        return 'SELL'

    return None

@app.get("/signals")
async def get_filtered_signals():
    signals = []
    try:
        for symbol in SYMBOL_LIST:
            token_info = get_token_info(symbol).iloc[0]
            token = token_info['token']
            symbol_name = token_info['symbol']

            candle_data = get_historical_data(token)
            if candle_data:
                df = calculate_indicators(candle_data)
                signal = generate_signal(df)
                if signal:
                    current_price = df['close'].iloc[-1]
                    signals.append({
                        "symbol": symbol_name,
                        "token": token,
                        "price": current_price,
                        "signal": signal
                    })
        return signals if signals else {"message": "No signals generated for the monitored stocks"}
    except Exception as e:
        logger.error(f"Error fetching signals: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Run the application with: uvicorn main:app --reload
