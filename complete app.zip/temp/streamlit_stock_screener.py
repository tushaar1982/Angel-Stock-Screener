import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from time import sleep
from threading import Timer
from SmartApi import SmartConnect
from ta.trend import IchimokuIndicator, SMAIndicator
from ta.momentum import RSIIndicator
from ta.volatility import BollingerBands
from dotenv import load_dotenv
import os


# Load credentials from .env file
load_dotenv()
API_KEY = os.getenv("API_KEY")
USER_NAME = os.getenv("USER_NAME")
PWD = os.getenv("PWD")

SYMBOL_LIST = ["IDEA", "POLYCAB", "DABUR", "INDHOTEL"]
TRADED_SYMBOL = []
timeFrame = 60 + 5  # 60 seconds + buffer for API response
rsiPeriod = 11
bandLength = 31
lengthrsipl = 1
lengthtradesl = 9

# Streamlit app layout
st.set_page_config(page_title="Stock Screener", layout="wide")

st.title("Streamlit Stock Screener")
st.sidebar.header("Configuration")
st.sidebar.markdown("Enter your Angel Broking API credentials.")

# Function to initialize token mapping
@st.cache_data
def intializeSymbolTokenMap():
    url = 'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json'
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()
    df = pd.DataFrame.from_dict(data)
    df['expiry'] = pd.to_datetime(df['expiry'])
    df = df.astype({'strike': float})
    return df

# Function to get token info
def getTokenInfo(symbol, df, exch_seg='NSE'):
    return df[(df['exch_seg'] == exch_seg) & (df['name'] == symbol)].iloc[0]

# Function to calculate indicators
def calculate_indicator(data):
    df = pd.DataFrame(data['data'], columns=['timestamp', 'O', 'H', 'L', 'C', 'V'])
    df['C'] = df['C'].astype(float)

    ichi = IchimokuIndicator(low=df['L'], high=df['H'], window1=9, window2=26, window3=52, fillna=True)
    df['base_line'] = ichi.ichimoku_base_line()
    df['conversion_line'] = ichi.ichimoku_conversion_line()
    df['leading_span_a'] = ichi.ichimoku_a()
    df['leading_span_b'] = ichi.ichimoku_b()

    rsi = RSIIndicator(close=df['C'], window=rsiPeriod)
    df['RSI'] = rsi.rsi()

    sma = SMAIndicator(close=df['RSI'], window=bandLength)
    df['SMA'] = sma.sma_indicator()

    bb = BollingerBands(close=df['RSI'], window=bandLength, window_dev=1.6185)
    df['mid'] = bb.bollinger_mavg()

    df['FAST_SMA'] = SMAIndicator(close=df['RSI'], window=lengthrsipl).sma_indicator()
    df['SLOW_SMA'] = SMAIndicator(close=df['RSI'], window=lengthtradesl).sma_indicator()

    return df

# Function to fetch historical data
def getHistoricalAPI(api, token):
    to_date = datetime.now()
    from_date = to_date - timedelta(days=15)
    params = {
        "exchange": "NSE",
        "symboltoken": token,
        "interval": "ONE_HOUR",
        "fromdate": from_date.strftime("%Y-%m-%d %H:%M"),
        "todate": to_date.strftime("%Y-%m-%d %H:%M"),
    }
    return api.getCandleData(params)

# Function to check signals
def checkSignal(api, token_df):
    global TRADED_SYMBOL
    results = []
    for symbol in SYMBOL_LIST:
        if symbol in TRADED_SYMBOL:
            continue

        token_info = getTokenInfo(symbol, token_df)
        token = token_info['token']
        candel_data = getHistoricalAPI(api, token)

        if not candel_data:
            continue

        df = calculate_indicator(candel_data)
        latest = df.iloc[-1]
        previous = df.iloc[-2]

        if (
            previous['SLOW_SMA'] >= previous['FAST_SMA']
            and latest['FAST_SMA'] > latest['SLOW_SMA']
            and previous['mid'] >= 50
        ):
            TRADED_SYMBOL.append(symbol)
            
            results.append({"Symbol": symbol, "Signal": "BUY"})

        elif (
            previous['SLOW_SMA'] <= previous['FAST_SMA']
            and latest['FAST_SMA'] < latest['SLOW_SMA']
            and previous['mid'] <= 50
        ):
            TRADED_SYMBOL.append(symbol)
           
            results.append({"Symbol": symbol, "Signal": "SELL"})

    return pd.DataFrame(results)

# Main Streamlit application
def main():
    # Sidebar login
    with st.sidebar.form(key="login_form"):
        st.text_input("API Key", value=API_KEY, type="password", key="api_key")
        st.text_input("User Name", value=USER_NAME, key="user_name")
        st.text_input("Password", value=PWD, type="password", key="password")
        login_btn = st.form_submit_button(label="Login")

    if login_btn:
        api_key = st.session_state["api_key"]
        user_name = st.session_state["user_name"]
        password = st.session_state["password"]

        try:
            token_map = intializeSymbolTokenMap()
            api = SmartConnect(api_key=api_key)
            session = api.generateSession(user_name, password)
            st.sidebar.success("Login successful!")
            st.session_state["api"] = api
            st.session_state["token_map"] = token_map
        except Exception as e:
            st.sidebar.error(f"Login failed: {str(e)}")

    # Main content
    if "api" in st.session_state and "token_map" in st.session_state:
        api = st.session_state["api"]
        token_map = st.session_state["token_map"]

        st.subheader("Stock Signals")
        results = checkSignal(api, token_map)

        if not results.empty:
            st.write("### Signals Detected:")
            st.dataframe(results)
        else:
            st.write("No signals generated at the moment.")
