from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from datetime import datetime, timedelta
from ta.trend import SMAIndicator
import logging
import time

# Configure logging
logger = logging.getLogger("backend")
logger.setLevel(logging.DEBUG)

# File handler
file_handler = logging.FileHandler("backend_debug.log")
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

# Console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

# Add handlers to logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# Initialize FastAPI app
app = FastAPI()

# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock data for demonstration
SYMBOL_LIST = ["IDEA",
"POLYCAB",
"DABUR",
"INDHOTEL",
"PAGEIND",
"CUMMINSIND",
"INDIGO",
"GLENMARK",
"NAUKRI",
"TORNTPHARM",
"PVR",
"SRF",
"LTI",
"COFORGE",
"SIEMENS",
"MINDTREE",
"BERGEPAINT",
"AMARAJABAT",
"ITC",
"PIDILITIND",
"HINDUNILVR",
"OFSS",
"ASIANPAINT",
"BOSCHLTD",
"CIPLA",
"IBULHSGFIN",
"SUNTV",
"MFSL",
"CADILAHC",
"LALPATHLAB",
"TORNTPOWER",
"DRREDDY",
"MARICO",
"BHARATFORG",
"TATAPOWER",
"INDIAMART",
"BAJAJ-AUTO",
"GRASIM",
"NESTLEIND",
"MRF",
"JUBLFOOD",
"INDUSTOWER",
"COROMANDEL",
"VOLTAS",
"HINDPETRO",
"DEEPAKNTR",
"SHREECEM",
"FEDERALBNK",
"ULTRACEMCO",
"TITAN",
"MCDOWELL-N",
"BIOCON",
"INFY",
"IRCTC",
"PFIZER",
"BAJAJFINSV",
"STAR",
"HEROMOTOCO",
"SUNPHARMA",
"BRITANNIA",
"HCLTECH",
"TVSMOTOR",
"GODREJCP",
"HDFCAMC",
"BATAINDIA",
"CUB",
"LICHSGFIN",
"BHARTIARTL",
"DIVISLAB",
"MANAPPURAM",
"HAL",
"TATACONSUM",
"LTTS",
"GUJGASLTD",
"TCS",
"MARUTI",
"COALINDIA",
"MGL",
"MCX",
"METROPOLIS",
"TATACHEM",
"IPCALAB",
"APLLTD",
"ALKEM",
"RBLBANK",
"DIXON",
"EXIDEIND",
"COLPAL",
"L&TFH",
"UPL",
"NAM-INDIA",
"AARTIIND",
"PNB",
"M&M",
"GMRINFRA",
"ASTRAL",
"AMBUJACEM",
"ACC",
"APOLLOTYRE",
"SBILIFE",
"PEL",
"RELIANCE",
"NAVINFLUOR",
"BANDHANBNK",
"SRTRANSFIN",
"TECHM",
"HAVELLS",
"AUROPHARMA",
"ABFRL",
"MUTHOOTFIN",
"KOTAKBANK",
"POWERGRID",
"APOLLOHOSP",
"ICICIGI",
"RAMCOCEM",
"AXISBANK",
"SYNGENE",
"IDFCFIRSTB",
"ASHOKLEY",
"BAJFINANCE",
"LT",
"ADANIPORTS",
"GODREJPROP",
"CANFINHOME",
"GRANULES",
"ESCORTS",
"NTPC",
"SBIN",
"ADANIENT",
"HDFC",
"BANKBARODA",
"WIPRO",
"CHOLAFIN",
"HDFCBANK",
"PETRONET",
"HDFCLIFE",
"TRENT",
"BALKRISIND",
"BPCL",
"TATAMOTORS",
"BHEL",
"PFC",
"RECLTD",
"M&MFIN",
"INDUSINDBK",
"MOTHERSUMI",
"MPHASIS",
"GAIL",
"BEL",
"ZEEL",
"UBL",
"ICICIBANK",
"IGL",
"EICHERMOT",
"IOC",
"ICICIPRULI",
"AUBANK",
"CONCOR",
"DLF",
"JSWSTEEL",
"IEX",
"PIIND",
"SAIL",
"JINDALSTEL",
"ONGC",
"CANBK",
"HINDALCO",
"TATASTEEL",
"VEDL",
"NMDC",
"LUPIN",
"NATIONALUM"]

# Fetch historical data (mock implementation for demo)
def get_historical_data(symbol):
    logger.info(f"Fetching historical data for symbol: {symbol}")
    # Generate mock candle data
    date_range = pd.date_range(datetime.now() - timedelta(days=15), periods=100, freq="H")
    data = {
        "timestamp": date_range,
        "open": [100 + i for i in range(100)],
        "high": [105 + i for i in range(100)],
        "low": [95 + i for i in range(100)],
        "close": [98 + i for i in range(100)],
        "volume": [1000 + 10 * i for i in range(100)],
    }
    logger.info(f"Historical data fetched successfully for symbol: {symbol}")
    return pd.DataFrame(data)

# Indicator calculation
def calculate_indicators_with_strategy(df):
    logger.debug("Calculating indicators (SMA 20 and SMA 200)")
    df.set_index('timestamp', inplace=True)

    # Calculate SMA (20 and 200)
    sma_20 = SMAIndicator(close=df['close'], window=20)
    sma_200 = SMAIndicator(close=df['close'], window=200)

    df['SMA_20'] = sma_20.sma_indicator()
    df['SMA_200'] = sma_200.sma_indicator()
    logger.debug("Indicators calculated successfully")
    return df

# Signal generation logic
def generate_signal_with_strategy(df):
    latest = df.iloc[-1]
    logger.debug("Generating signal based on strategy conditions")

    # Buy Signal Conditions
    if (
        latest['close'] < latest['SMA_20'] and
        abs((latest['close'] - latest['SMA_20']) / latest['SMA_20']) >= 0.018 and
        abs((latest['SMA_20'] - latest['SMA_200']) / latest['SMA_200']) >= 0.018
    ):
        logger.info("Buy signal generated")
        return 'BUY'

    # Sell Signal Conditions
    if (
        latest['close'] > latest['SMA_20'] and
        abs((latest['close'] - latest['SMA_20']) / latest['SMA_20']) >= 0.018 and
        abs((latest['SMA_20'] - latest['SMA_200']) / latest['SMA_200']) >= 0.018
    ):
        logger.info("Sell signal generated")
        return 'SELL'

    logger.info("No signal generated")
    return None

@app.get("/signals")
async def get_filtered_signals():
    logger.info("Fetching signals for all symbols")
    signals = []
    try:
        for symbol in SYMBOL_LIST:
            logger.debug(f"Processing symbol: {symbol}")
            time.sleep(1)
            candle_data = get_historical_data(symbol)
            if not candle_data.empty:
                df = calculate_indicators_with_strategy(candle_data)
                signal = generate_signal_with_strategy(df)
                if signal:
                    current_price = df['close'].iloc[-1]
                    signals.append({
                        "symbol": symbol,
                        "price": current_price,
                        "signal": signal
                    })
        logger.info(f"Signals generated: {signals}")
        return signals if signals else {"message": "No signals generated for the monitored stocks"}
    except Exception as e:
        logger.error(f"Error fetching signals: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")
